import 'package:flutter/material.dart';

import 'package:pawnet/loginsignup.dart';

void main() =>runApp (
  new MaterialApp(
    debugShowCheckedModeBanner: false,
    title: "PawNet",
    home: new LoginSignupPage(),
  )

);
