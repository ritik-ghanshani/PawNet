import 'package:flutter/material.dart';

const myPrimaryColor = const Color(0xFFE91E63);
const myAccentColor = const Color(0xFFE91E63);